/*
 * Copyright (C) 2007, 2009, 2011, 2015 XStream Committers.
 * All rights reserved.
 *
 * The software in this package is published under the terms of the BSD
 * style license a copy of which has been included with this distribution in
 * the LICENSE.txt file.
 * 
 * Created on 25. June 2007 by Joerg Schaible
 */
package com.thoughtworks.xstream.tools.benchmark.model;

/**
 * Class with 100 fields.
 * 
 * @since 1.4
 * @deprecated As of 1.4.9 use JMH instead
 */
public class A100Fields {

    String field000;
    String field001;
    String field002;
    String field003;
    String field004;
    String field005;
    String field006;
    String field007;
    String field008;
    String field009;
    String field010;
    String field011;
    String field012;
    String field013;
    String field014;
    String field015;
    String field016;
    String field017;
    String field018;
    String field019;
    String field020;
    String field021;
    String field022;
    String field023;
    String field024;
    String field025;
    String field026;
    String field027;
    String field028;
    String field029;
    String field030;
    String field031;
    String field032;
    String field033;
    String field034;
    String field035;
    String field036;
    String field037;
    String field038;
    String field039;
    String field040;
    String field041;
    String field042;
    String field043;
    String field044;
    String field045;
    String field046;
    String field047;
    String field048;
    String field049;
    String field050;
    String field051;
    String field052;
    String field053;
    String field054;
    String field055;
    String field056;
    String field057;
    String field058;
    String field059;
    String field060;
    String field061;
    String field062;
    String field063;
    String field064;
    String field065;
    String field066;
    String field067;
    String field068;
    String field069;
    String field070;
    String field071;
    String field072;
    String field073;
    String field074;
    String field075;
    String field076;
    String field077;
    String field078;
    String field079;
    String field080;
    String field081;
    String field082;
    String field083;
    String field084;
    String field085;
    String field086;
    String field087;
    String field088;
    String field089;
    String field090;
    String field091;
    String field092;
    String field093;
    String field094;
    String field095;
    String field096;
    String field097;
    String field098;
    String field099;
}
