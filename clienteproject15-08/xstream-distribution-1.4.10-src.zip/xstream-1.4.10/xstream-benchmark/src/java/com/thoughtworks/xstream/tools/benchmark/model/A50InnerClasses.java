/*
 * Copyright (C) 2007, 2009, 2011, 2015 XStream Committers.
 * All rights reserved.
 *
 * The software in this package is published under the terms of the BSD
 * style license a copy of which has been included with this distribution in
 * the LICENSE.txt file.
 * 
 * Created on 13. September 2007 by Joerg Schaible
 */
package com.thoughtworks.xstream.tools.benchmark.model;

/**
 * Class with inner classes 50 levels deep.
 * 
 * @since 1.4
 * @deprecated As of 1.4.9 use JMH instead
 */
public class A50InnerClasses {

    public class L00 { String field000;
    public class L01 { String field001;
    public class L02 { String field002;
    public class L03 { String field003;
    public class L04 { String field004;
    public class L05 { String field005;
    public class L06 { String field006;
    public class L07 { String field007;
    public class L08 { String field008;
    public class L09 { String field009;
    public class L10 { String field010;
    public class L11 { String field011;
    public class L12 { String field012;
    public class L13 { String field013;
    public class L14 { String field014;
    public class L15 { String field015;
    public class L16 { String field016;
    public class L17 { String field017;
    public class L18 { String field018;
    public class L19 { String field019;
    public class L20 { String field020;
    public class L21 { String field021;
    public class L22 { String field022;
    public class L23 { String field023;
    public class L24 { String field024;
    public class L25 { String field025;
    public class L26 { String field026;
    public class L27 { String field027;
    public class L28 { String field028;
    public class L29 { String field029;
    public class L30 { String field030;
    public class L31 { String field031;
    public class L32 { String field032;
    public class L33 { String field033;
    public class L34 { String field034;
    public class L35 { String field035;
    public class L36 { String field036;
    public class L37 { String field037;
    public class L38 { String field038;
    public class L39 { String field039;
    public class L40 { String field040;
    public class L41 { String field041;
    public class L42 { String field042;
    public class L43 { String field043;
    public class L44 { String field044;
    public class L45 { String field045;
    public class L46 { String field046;
    public class L47 { String field047;
    public class L48 { String field048;
    public class L49 { String field049;
    }}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
}
